from mpi4py import MPI
import dzeson
import json
import time
import os

EXCEPTIONS = "exceptions.txt"

def initialize(country):
    """
    initializes the collection files 
    """
    for i in range(size):
        with open(f'temp/mpi{i}.txt', 'w', encoding='utf-8') as f:f.write('')
        with open(f'temp/{i}{EXCEPTIONS}', 'w', encoding='utf-8') as f:f.write('')
    if not os.path.isfile(f'{country}_amenities.json'):
        dzeson.format_initial_file(country)
    with open(f'{country}_amenities.json', 'r', encoding = 'utf-8') as file:
        answer = json.load(file)
    return answer

def writeData(data, index):
    if data is not None:
        with open(f'temp/mpi{index}.txt', 'a', encoding='utf-8') as f:
            f.write(json.dumps(data) + '\n')
    else:
        print(f'Warning: Attempted to write None to file mpi{index}.txt')


def combine_data(size, country, total_time_elapsed):
    """
    combines data from different files into one
    """
    for i in range(size):
        with open(f'temp/mpi{i}.txt', 'a', encoding='utf-8') as f:f.write('')

    with open('MPItimetaken.txt', 'w', encoding = 'utf-8') as timing:
        timing.write(f'Total time taken: {(total_time_elapsed/size):.4f} seconds\n')

    data = {}
    for i in range(size):
        with open(f'temp/mpi{i}.txt', 'r', encoding='utf-8') as input_file:
            # Pause for 1 second
            time.sleep(1)
            for line in input_file:
                if line.strip() != 'null':
                    try:
                        answer = json.loads(line)
                        if answer is not None:
                            for element in answer:
                                data[len(data)] = element
                        else:
                            print(f'Error: JSON data in file mpi{i}.txt is None')
                    except json.JSONDecodeError as e:
                        print(f'Error decoding JSON from file mpi{i}.txt: {e}')
                else:
                    print(f'Skipped null data in file mpi{i}.txt')
    with open(f'{country}_mpi.txt', 'w', encoding='utf-8') as output:
        json.dump(data, output)




if __name__ == '__main__':
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    country = 'lt'

    if rank == 0:
        answer = initialize(country)
        wiki_things = [entry for entry in answer\
                       if 'tags' in entry and 'wikipedia' in entry['tags']]
    else:
        wiki_things = None
    time.sleep(1)

    start_time = MPI.Wtime()

    wiki_things = comm.bcast(wiki_things, root=0)

    last = time.time()
    for index, datum in enumerate(wiki_things[rank::size]):
        part = datum['tags']['wikipedia']
        print(f"part: {part}", flush=True)
        data = dzeson.get_singular_data(datum, rank, index)
        writeData(data, rank)
        time_taken = time.time()-last
        if int(time_taken) < 2:
            time.sleep(2)
        last = time.time()

    time_elapsed = MPI.Wtime() - start_time
    print(f'worker {rank} is done in {time_elapsed} seconds')
    total_time_elapsed = comm.reduce(time_elapsed, op=MPI.SUM, root=0)
    if rank == 0:
        combine_data(size, country, total_time_elapsed)
