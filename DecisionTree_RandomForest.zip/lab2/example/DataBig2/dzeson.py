from bs4 import BeautifulSoup as bs
from mpi4py import MPI
import traceback
import requests
import json
import re

BINARY = ['phone', 'heritage', 'image', 'website', 'building', 'historic']
WHEELCHAIR = ['yes', 'no', 'limited', 'unspecified']
DENOMINATION = ['roman_catholic', 'protestant', 'catholic', 'lutheran', 'other', 'unspecified']
RELIGION = ['christian', 'other', 'unspecified']
AMENITY = ['bank', 'restaurant', 'hospital', 'university', 'townhall', 'fountain',
           'courthouse', 'theatre', 'school', 'place_of_worship', 'other']
CATEGORICS = ['wheelchair', 'denomination', 'religion', 'amenity']
CITIES = []
EXCEPTIONS = "exceptions.txt"

def format_initial_file(country: str) -> None:
    """
    collects overpass turbo data and writes a more usable format to a file
    """
    with open(f'big_amenities/{country}_amenities_{country}_en.json', 'r', encoding = 'utf-8') as input_file:
        answer = json.load(input_file)
        wiki_things = [entry for entry in answer["elements"] if "tags" in entry and "wikipedia" in entry["tags"]]
        wiki_things = [{key: thing[key] for key in thing if key not in ['nodes', 'type', 'id', 'members']} for thing in wiki_things]

        with open(f'{country}_amenities.json', 'w', encoding = 'utf-8') as output_file:
            json.dump(wiki_things, output_file)

def get_amenities(entry):
    """
    gets the values of amenities from the wikipedia page
    """
    keys = entry.keys()
    binary = [key in keys for key in BINARY]
    categorics = [entry[i] if i in keys else 'unspecified' for i in ['wheelchair', 'denomination', 'religion', 'amenity']]
    return binary, categorics

def format_data(wikidata, entry) -> dict:
    """
    formats data from wikipedia and wikidata into a single dictionary
    """
    wikidata_data = get_wikidata_info(wikidata)
    
    data = get_most_data(entry['tags']['wikipedia'], wikidata_data, entry)
    data['wikidata'] = wikidata
    amenities = get_amenities(entry['tags'])
    for index, category in enumerate(CATEGORICS):
        data[category] = amenities[1][index]
    data.update(dict(zip(BINARY, amenities[0])))
    data.update(wikidata_data)
    return data

"""def get_singular_data(entry, rank, index) -> None:
    
    #collects the data from wikipedia and wikidata and writes it to a file
    
    with open(f'temp/mpi{rank}.txt', 'a', encoding='utf-8') as output_file:
        name = entry['tags']['wikipedia']
        wikidata = entry['tags'].get('wikidata', '')
        try:
            #f.write(f'{format_data(wikidata, entry)}\n')
            data = format_data(wikidata, entry)
            json.dump(data, output_file)
            output_file.write(', ')
        except Exception as e:
            with open(f'temp/{rank}{EXCEPTIONS}', 'a', encoding='utf-8') as f:
                f.write(str(name) + f'[{rank}] - {index}\n')
                f.write(str(traceback.format_exc()) + '\n\n')"""

def get_singular_data(entry, rank, index) -> dict:
    name = entry['tags']['wikipedia']
    wikidata = entry['tags'].get('wikidata', '')
    try:
        data = format_data(wikidata, entry)
        return data
    except Exception as e:
        with open(f'temp/{rank}{EXCEPTIONS}', 'a', encoding='utf-8') as f:
            f.write(str(name) + f'[{rank}] - {index}\n')
            f.write(str(traceback.format_exc()) + '\n\n')
    return None

def get_most_data(page, wikidata_data, entry):
    """
    gets most of the valuable data that can be extracted from wikipedia
    """
    api_url = f'https://{page[:2]}.wikipedia.org/w/api.php'
    params = {
    "action": "parse",
    "format": "json",
    "page": page,
    "prop": "links|externallinks|categories|langlinks|images|coordinates",
    "disabletoc": True,
    }
    response = requests.get(api_url, params=params).json()

    if re.search("class=\"redirectText\"", str(response)):
        soup = bs(str(response), "html.parser")
        title = soup.find("ul", class_="redirectText").find("a")['title']
        return get_most_data(page[:2]+":"+title, wikidata_data, entry)
    links = [link["*"] for link in response["parse"]["links"]]
    if len(links) == 0:
        return {}
    
    try:
        coordinates = wikidata_data['coordinates'] if 'lat' not in entry else (entry['lat'], entry['lon'])
    except:
        coordinates = get_coordinates(page)
    images = response["parse"]["images"]
    languages = response["parse"]["langlinks"]
    categories = response["parse"]["categories"]
    references = response["parse"]["externallinks"]

    url = f"https://{page[:2]}.wikipedia.org/api/rest_v1/page/summary/{page[3:]}"
    response = requests.get(url)
    summary = response.json()["extract"]
    keys = ['wikipedia', 'wikidata', 'links', 'backlinks', 'images', 'languages', 'references', 'categories',
            'summary_word_count', 'within_1km']
    
    values = [page, "", links, get_backlinks(page), len(images), len(languages), len(references), len(categories),
              len(summary), len(get_geocoord(coordinates, api_url))]
    
    return dict(zip(keys, values))

def get_geocoord(coordinates, api_url):
    """
    gets the amount of objects within 1km of the object
    """
    if coordinates == ():
        return []
    params = {
    'action': 'query',
    'list': 'geosearch',
    'gscoord': f'{coordinates[0]}|{coordinates[1]}',
    'gsradius': '1000',
    'format': 'json',
    'gslimit': '500'
    }
    response = requests.get(api_url, params=params).json()
    return [page['title'] for page in response['query']['geosearch']]

def get_coordinates(page):
    """
    gets object's coordinates from it's wikipedia page
    """
    params = {
        "action": "query",
        "titles": page,
        "prop": "coordinates",
        "format": "json"
    }
    response = requests.get(f"https://{page[:2]}.wikipedia.org/w/api.php", params=params).json()
    page_id = list(response['query']['pages'].keys())[0]
    coordinates = response['query']['pages'][page_id]['coordinates'][0]

    return (coordinates['lat'], coordinates['lon'])

def get_backlinks(page):
    """
    gets the number of links pointing into this page
    """
    params = {
        "action": "query",
        "format": "json",
        "list": "backlinks",
        "bltitle": page
    }
    backlinks = []
    lastContinue = {}
    while True:
        req = params.copy()
        req.update(lastContinue)
        current_back = []
        result = requests.get(f'https://{page[:2]}.wikipedia.org/w/api.php', params=req).json()
        if 'query' in result:
            current_back = result['query']['backlinks']
        if 'continue' not in result:
            try:
                backlinks.extend([link["title"] for link in current_back])
            except:
                pass
            break
        lastContinue = result['continue'] 
        backlinks.extend([link["title"] for link in current_back])
    return backlinks

def get_wikidata_info(wikidata_id):
    """
    accesses wikidata api to retrieve various information
    """
    if wikidata_id == '':
        return {}
    url = 'https://www.wikidata.org/w/api.php'
    params = {
        'action': 'wbgetentities',
        'ids': wikidata_id,
        'format': 'json',
    }
    response = requests.get(url, params=params)
    data = response.json()
    entries = data['entities'][wikidata_id]
    claims = entries['claims']
    
    answer = {}
    answer['wikidata_languages'] = len(entries['labels'])
    answer['aliases'] = len(entries['aliases'])
    coords = claims['P625'][0]['mainsnak']['datavalue']['value'] if 'P625' in claims else None
    answer['coordinates'] = (coords['latitude'], coords['longitude']) if coords != None else ()
    answer['elevation'] = claims['P2044'][0]['mainsnak']['datavalue']['value']['amount'] if 'P2044' in claims else '+0'
    
    return answer

def key_types(wiki_things):
    """
    determines most common types of objects
    """
    not_useful = ['source', 'addr:city', 'addr:street', 'addr:postcode', 'wikimedia_commons', 'addr:country', 'addr:suburb',
                  'diocese', 'deanery', 'parish', 'heritage:operator', 'start_date', 'addr:housenumber', 'operator',
                  'name']
    all_tags = []
    for entry in wiki_things:
        keys = entry['tags'].keys()
        if 'amenity' in keys:
            all_tags.extend(entry['tags'].keys())
    filtered = [(tag, all_tags.count(tag)) for tag in set(all_tags)]
    maximum = max(filtered, key = lambda x: x[1])[1]
    filtered = [tag for tag in filtered if tag[1] > maximum/10 and tag[0] not in not_useful]
    filtered.sort(key = lambda x: int(x[1]))
    for i in filtered:
        print(i)
        counter = count_amenities(wiki_things, i[0])
        if i[0] in BINARY:
            print(f'{i[1]} yes, {len(wiki_things) - i[1]} no')
        else:
            print(f'{counter}')
        print()
    print(len(filtered))
    exit()

def count_amenities(wiki_things, amenity):
    """
    returns the number of amenities
    """
    found = []
    for entry in wiki_things:
        try:
            found.append(entry['tags'][amenity])
        except:
            continue
    entries = [(entry, found.count(entry)) for entry in set(found)]
    maximum = max(entries, key = lambda x: x[1])[1]
    entries = [entry for entry in entries if entry[1] > maximum/100]
    entries.sort(key = lambda x: int(x[1]))
    return entries

if __name__ == '__main__':
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()

    print(rank)
    print(size)
