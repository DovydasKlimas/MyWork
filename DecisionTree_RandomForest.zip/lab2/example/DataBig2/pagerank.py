import os
import time
import json
import subprocess
import numpy as np
from mpi4py import MPI

if __name__ == '__main__':
    country = 'lt'
    iterations = 10

    first = time.time()
    with open(f'{country}_mpi.txt', 'r', encoding = 'utf-8') as input_file:
        MPI_data = json.load(input_file)
    if not os.path.isfile(f'{country}_mpi_for_pagerank.json'):
        first = time.time()
        command = ['mpiexec', '-n', '12', 'python', 'MPI_filter_pagerankable.py', f'{country}_mpi_for_pagerank.json']
        subprocess.call(command)
        print(f'mpiexec took {time.time() - first:.4f} seconds')
    with open(f'{country}_mpi_for_pagerank.json', 'r', encoding = 'utf-8') as input_file:
        usable = json.load(input_file)
        # ['wikipedia', 'links', 'backlinks']
    N = int(len(usable))
    d = 0.85

    print(N)
    pages = [i[0][3:] for i in usable]
    page_ranks = np.array([len(i[2]) for i in usable])
    out_links = np.array([len(i[1]) for i in usable])
    multipliers = np.array(page_ranks/out_links*d)
    ones_matrix = np.zeros((N, N))
    link_matrix = np.zeros((N, N))
    
    for iteration in range(1, iterations+1):
        start = time.time()
        for index, row in enumerate(ones_matrix):
            line = np.zeros(N)
            for page in usable[index][1]:
                for i in [index for index, value in enumerate(pages) if page == value]:
                    line[i] = 1
            ones_matrix[index, :] = line
        
        for row in range(N):
            link_matrix[row, :] = ones_matrix[row, :] * multipliers[row]

        for i in range(N):
            page_ranks[i] = np.sum(link_matrix[:, i]) + (1-d)

        print(f'iteration {iteration} took {time.time()-start:.4f} seconds')
    page_ranks = page_ranks/np.max(page_ranks)
    usable = [i+[page_ranks[index]] for index, i in enumerate(usable)]

    new_list = [str([i[0], len(i[1]), len(i[2]), i[3]]) for i in usable]
    new_list = list(set(new_list))
    new_list.sort(key = lambda x: float(x.split(',')[-1][1:-1]), reverse = True)

    print(f'Total time taken: {time.time() - first:.4f} seconds')
    with open(f'{country}_mpi_pageranked.txt', 'w', encoding = 'utf-8') as output_file:
        for item in new_list:
            output_file.write(f'{item}\n')

#lithuanian_mpi_10s.txt
#Total time taken: 1467.4819 seconds

#lithuanian_mpi_2s.txt
#Total time taken: 426.3661 seconds

#german_mpi_2.txt
#Total time taken: 5533.6824 seconds

#lithuanian_mpi_full_links.txt
#Total time taken: 433.6252 seconds

#german_mpi_full_links.txt
#Total time taken: 6383.9097 seconds
#Time taken to filter pagerank'able: 413.2742142677307 