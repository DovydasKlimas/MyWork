from bs4 import BeautifulSoup as bs
import requests
import time
import re

BINARY = ['phone', 'heritage', 'image', 'website', 'building', 'historic']

def get_data(page, wikidata_data, entry):
    api_url = f'https://{page[:2]}.wikipedia.org/w/api.php'
    params = {
    "action": "parse",
    "format": "json",
    "page": page,
    "prop": "links|externallinks|categories|langlinks|images|coordinates",
    "disabletoc": True,
    }
    response = requests.get(api_url, params=params).json()

    if re.search("class=\"redirectText\"", str(response)):
        soup = bs(str(response), "html.parser")
        title = soup.find("ul", class_="redirectText").find("a")['title']
        return get_data(page[:2]+":"+title, wikidata_data, entry)
    links = [link["*"] for link in response["parse"]["links"]]
    if len(links) == 0:
        return {}
    
    try:
        coordinates = wikidata_data['coordinates'] if 'lat' not in entry else (entry['lat'], entry['lon'])
    except:
        coordinates = get_coordinates(page)
    images = response["parse"]["images"]
    languages = response["parse"]["langlinks"]
    categories = response["parse"]["categories"]
    references = response["parse"]["externallinks"]

    url = f"https://{page[:2]}.wikipedia.org/api/rest_v1/page/summary/{page[3:]}"
    response = requests.get(url)
    summary = response.json()["extract"]
    keys = ['wikipedia', 'wikidata', 'links', 'backlinks', 'images', 'languages', 'references', 'categories',
            'summary_word_count', 'within_1km']
    
    values = [page, "", links, get_backlinks(page), len(images), len(languages), len(references), len(categories),
              len(summary), len(get_geocoord(coordinates, api_url))]
    
    return dict(zip(keys, values))

def get_coordinates(page):
    params = {
        "action": "query",
        "titles": page,
        "prop": "coordinates",
        "format": "json"
    }
    response = requests.get(f"https://{page[:2]}.wikipedia.org/w/api.php", params=params).json()
    page_id = list(response['query']['pages'].keys())[0]
    coordinates = response['query']['pages'][page_id]['coordinates'][0]

    return (coordinates['lat'], coordinates['lon'])
def get_backlinks(page):
    params = {
        "action": "query",
        "format": "json",
        "list": "backlinks",
        "bltitle": page
    }
    backlinks = []
    lastContinue = {}
    while True:
        req = params.copy()
        req.update(lastContinue)
        current_back = []
        result = requests.get(f'https://{page[:2]}.wikipedia.org/w/api.php', params=req).json()
        if 'query' in result:
            current_back = result['query']['backlinks']
        if 'continue' not in result:
            try:
                backlinks.extend([link["title"] for link in current_back])
            except:
                pass
            break
        lastContinue = result['continue'] 
        backlinks.extend([link["title"] for link in current_back])
    return backlinks

def get_geocoord(coordinates, api_url):
    if coordinates == ():
        return []
    params = {
    'action': 'query',
    'list': 'geosearch',
    'gscoord': f'{coordinates[0]}|{coordinates[1]}',
    'gsradius': '1000',
    'format': 'json',
    'gslimit': '500'
    }
    response = requests.get(api_url, params=params).json()
    return [page['title'] for page in response['query']['geosearch']]

def get_wikidata_info(wikidata_id):
    if wikidata_id == '':
        return {}
    url = 'https://www.wikidata.org/w/api.php'
    params = {
        'action': 'wbgetentities',
        'ids': wikidata_id,
        'format': 'json',
    }
    response = requests.get(url, params=params)
    data = response.json()
    entries = data['entities'][wikidata_id]
    claims = entries['claims']
    
    answer = {}
    answer['wikidata_languages'] = len(entries['labels'])
    answer['aliases'] = len(entries['aliases'])
    coords = claims['P625'][0]['mainsnak']['datavalue']['value'] if 'P625' in claims else None
    answer['coordinates'] = (coords['latitude'], coords['longitude']) if coords != None else ()
    answer['elevation'] = claims['P2044'][0]['mainsnak']['datavalue']['value']['amount'] if 'P2044' in claims else '+0'
    
    return answer

def key_types(wiki_things):
    not_useful = ['source', 'addr:city', 'addr:street', 'addr:postcode', 'wikimedia_commons', 'addr:country', 'addr:suburb',
                  'diocese', 'deanery', 'parish', 'heritage:operator', 'start_date', 'addr:housenumber', 'operator',
                  'name']
    all_tags = []
    for entry in wiki_things:
        keys = entry['tags'].keys()
        if 'amenity' in keys:
            all_tags.extend(entry['tags'].keys())
    filtered = [(tag, all_tags.count(tag)) for tag in set(all_tags)]
    maximum = max(filtered, key = lambda x: x[1])[1]
    filtered = [tag for tag in filtered if tag[1] > maximum/10 and tag[0] not in not_useful]
    filtered.sort(key = lambda x: int(x[1]))
    for i in filtered:
        print(i)
        counter = count_amenities(wiki_things, i[0])
        if i[0] in BINARY:
            print(f'{i[1]} yes, {len(wiki_things) - i[1]} no')
        else:
            print(f'{counter}')
        print()
    print(len(filtered))
    exit()

def count_amenities(wiki_things, amenity):
    found = []
    for entry in wiki_things:
        try:
            found.append(entry['tags'][amenity])
        except:
            continue
    entries = [(entry, found.count(entry)) for entry in set(found)]
    maximum = max(entries, key = lambda x: x[1])[1]
    entries = [entry for entry in entries if entry[1] > maximum/100]
    entries.sort(key = lambda x: int(x[1]))
    return entries

if __name__ == '__main__':
    #get_data("it:Istituto nazionale di statistica", ())
    first = time.time()
    print(len(get_backlinks("it:Istituto nazionale di statistica")))
    print(time.time() - first)
    get_data('lt:Klaipėdos turizmo mokykla', '', '')


#LT:
#Total time taken: 2000.7632477283478
#Average time taken: 1.3302947125853377
