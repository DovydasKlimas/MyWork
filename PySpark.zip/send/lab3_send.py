from pyspark.sql import SparkSession
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.regression import RandomForestRegressor, LinearRegression, DecisionTreeRegressor
import pyspark.sql.functions as funcs
import pyspark.sql as sql
import os

def onehot(data, selected_col):
    for i in [row[selected_col] for row in data.select(selected_col).distinct().collect()]:
        data = data.withColumn(f'{selected_col} {i}', funcs.when(funcs.col(selected_col) == i, 1).otherwise(0))
    return data

def format_data(data, ans):
    data = data.dropna(subset=['Vict Sex', 'Vict Descent', 'Premis Cd'])
    data = data.drop(*['DR_NO', 'Date Rptd', 'DATE OCC', 'Crm Cd Desc', 'Mocodes', 'Vict Descent', 'Status', 'Status Desc', 'Premis Desc', 'Weapon Desc', 'Crm Cd 1', 'Crm Cd 2', 'Crm Cd 3', 'Crm Cd 4', 'LOCATION', 'Cross Street'])
    data = data.fillna({'Weapon Used Cd': -1})
    data = data.filter(funcs.col('Vict Sex').isin(['M', 'F']))
    data = data.filter(~funcs.col('Vict Age').isin([0]))
    data = data.withColumn('Vict Sex Male', funcs.when(funcs.col('Vict Sex') == 'M', 1).otherwise(0))
    data = data.drop('Vict Sex')
    all_columns = data.columns
    new_columns_order = [ans] + [col_name for col_name in all_columns if col_name != ans]
    data = data.select(*new_columns_order)

    data = onehot(data, 'Crm Cd')
    data = onehot(data, 'AREA NAME')
    data = data.drop(*['AREA NAME', 'Crm Cd'])
    return data, ans

def regression(data, selected_col, Regressor):
    regressor = Regressor(featuresCol = 'features', labelCol=selected_col)
    train, test = data.randomSplit([0.8, 0.2])
    model = regressor.fit(train)
    predictions = model.transform(test)
    predictions = predictions.withColumn('predicted age', funcs.round(funcs.col("prediction")))
    predictions = predictions.withColumn('difference', funcs.abs(funcs.col("Vict Age") - funcs.col("predicted age")))
    predictions.show(10)

    evaluator = RegressionEvaluator(labelCol=selected_col, predictionCol="prediction", metricName="rmse")
    rmse = evaluator.evaluate(predictions)
    print(f"Mean Squared Error (MSE): {round(rmse**2, 2)}")

if __name__ == '__main__':
    spark = SparkSession.builder.getOrCreate()
    df = spark.read.csv(f'{os.getcwd()}\\crime.csv', header=True, inferSchema=True)

    ans = 'Vict Age'
    data, ans = format_data(df, ans)
    
    vectorAssembler = VectorAssembler(inputCols = [col for col in data.columns if col != ans], outputCol = 'features')
    data = vectorAssembler.transform(data)
    data = data.select(['features', ans])

    regression(data, ans, LinearRegression)
    regression(data, ans, DecisionTreeRegressor)
    regression(data, ans, RandomForestRegressor)

    spark.stop()

