from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt
import sklearn.svm as svm
import pandas as pd
import numpy as np
import pickle
import time
import os

gamma = 0
bias = 0

class SVM:
    def __init__(self, n_iters=1000, C=1., linear=False):
        self.linear = linear
        self.n_iters = n_iters
        self.b = None
        self.C = C
        self.lagrangeMultipliers = []
        self.errorCache = []
        self.tol = 1e-12
        self.XTrain = []
        self.yTrain = []
        self.supportVector = []
        self.supportVectorValue = []

    def kernel(self, point1: np.ndarray, point2: np.ndarray):
        if self.linear:
            return np.dot(point1, point2.T)
        return np.power(np.dot(point1, point2.T) + 1, 3) #poly
        sq_diffs = np.sum(point1**2) - \
                2*np.dot(point1, point2.T) + \
                np.sum(point2**2)
        global gamma
        global bias
        return -gamma * sq_diffs + bias # RBF

    def takeStep(self, i1, i2, X, y):
        if (i1 == i2): return 0

        C = self.C
        eps = 1e-12
        alpha1 = self.lagrangeMultipliers[i1]
        alpha2 = self.lagrangeMultipliers[i2]
        y1 = y[i1]
        y2 = y[i2]
        E1 = self.errorCache[i1]
        E2 = self.errorCache[i2]

        s = y1 * y2
        if y1 != y2:
            L = np.max([0, alpha2-alpha1])
            H = np.min([C, C+alpha2-alpha1])
        else:
            L = np.max([0, alpha2 + alpha1 -C])
            H = np.min([C, alpha2+alpha1])
        if L == H:
            return 0
        k11 = self.kernel(X[i1,:], X[i1,:])
        k12 = self.kernel(X[i1, :], X[i2, :])
        k22 = self.kernel(X[i2, :], X[i2, :])
        eta = k11 + k22 - 2*k12
        if (eta > 0):
            a2 = alpha2 + y2*(E1-E2)/eta
            if (a2 < L):
                a2 = L
            elif (a2 > H):
                a2 = H
        else:
            f1 = y1 * (E1+ self.b) - alpha1*k11 - s*alpha2*k12
            f2 = y2 * (E2 + self.b) - s*alpha1 * k12 - alpha2 * k22
            L1 = alpha1 + s*(alpha2-L)
            H1 = alpha1 + s*(alpha2-H)
            PsiL = L1 * f1 + L * f2 + 0.5 * L1 ** 2 * k11 + 0.5 * L ** 2 * k22 + s * L * L1 * k12
            PsiH = H1 * f1 + H * f2 + 0.5 * H1 ** 2 * k11 + 0.5 * H ** 2 * k22 + s * H * H1 * k12
            if PsiL < PsiH-eps:
                a2 = L
            elif(PsiL > PsiH + eps):
                a2 = H
            else:
                a2 = alpha2
        if abs(a2 - alpha2) < eps*(a2+alpha2+eps):
            return 0
        a1 = alpha1 + s*(alpha2-a2)
        b1 = E1 + y1 * (a1 - alpha1) * k11 + y2 * (a2 - alpha2) * k12 + self.b
        b2 = E2 + y1 * (a1 - alpha1) * k12 + y2 * (a2 - alpha2) * k22 + self.b
        if (a1 > 0) and (a1 < self.C):
            self.b = b1
        elif (a2 > 0) and (a2 < self.C):
            self.b = b2
        elif L != H:
            self.b = (b1+b2)/2

        # update weight vector if SVM is linear
        if self.linear:
            self.w += y1*(a1 - alpha1)*X[i1,:] + y2*(a2-alpha2)*X[i2,:]

        self.lagrangeMultipliers[i1] = a1
        self.lagrangeMultipliers[i2] = a2
        self.errorCache = self.predict(X)[0] - y
        return  1

    def examineExample(self, i2, X, y):
        E2 = self.errorCache[i2]
        indices = np.where((self.lagrangeMultipliers > 0) & (self.lagrangeMultipliers < self.C))[0]
        if (len(indices) > 1):
            errorDif = np.abs(self.errorCache - E2)
            index = np.argmax(errorDif[indices])

            i1 = indices[index]
            if (self.takeStep(i1, i2, X, y) == 1):
                return 1

        np.random.shuffle(indices)
        for i1 in indices:
            if (self.takeStep(i1, i2, X, y) == 1):
                return 1

        indices = np.arange(np.shape(X)[0])
        np.random.shuffle(indices)
        for i1 in indices:
            if (self.takeStep(i1, i2, X, y) == 1):
                return 1
        return 0

    def fit(self, X, y):
        self.XTrain = X
        self.yTrain = y
        self.lagrangeMultipliers = np.zeros((np.shape(X)[0], ))
        self.b = 0
        self.w = np.random.random((np.shape(X)[1], ))

        self.supportVector = self.XTrain
        self.supportVectorValue = self.yTrain
        self.supportVectorIndices = np.arange(len(self.XTrain))
        self.errorCache = self.predict(X)[0] - y
        numChanged = 0
        examineAll = True
        iter = 0
        
        while(((numChanged > 0) | examineAll ) & (iter < self.n_iters)):
            timer = time.time()
            iter += 1
            numChanged = 0
            if (examineAll):
                indices = np.arange(len(X))
                np.random.shuffle(indices)
                for i in indices:
                    numChanged += self.examineExample(i, X, y)
            else:
                indices = np.where((self.lagrangeMultipliers > 0) & (self.lagrangeMultipliers < self.C))[0]
                for i in indices:
                    numChanged += self.examineExample(i, X, y)
            if (examineAll):
                examineAll = False
            elif (numChanged == 0):
                examineAll = True

            IS = np.abs(self.lagrangeMultipliers) > self.tol
            self.supportVector = self.XTrain[IS, :]
            self.supportVectorValue = self.yTrain[IS]
            self.supportVectorIndices = np.where(IS)
            print(f'iteration: {iter}/{self.n_iters}. Time taken per iter: {round(time.time() - timer, 2)}s', end = '\r')
        print()

    def predict(self, X):
        if self.linear:
            approx = np.dot(X, self.w) - self.b # if SVM is linear
            return (approx, np.sign(approx))
        
        supportAlpha = self.lagrangeMultipliers[self.supportVectorIndices]
        approx = np.dot(self.supportVectorValue * supportAlpha, self.kernel(self.supportVector, X)) - self.b
        return (approx, np.sign(approx))

def prepare_data(filepath: str):
    data = pd.read_csv(filepath)
    data.rename(columns={
                    'SBP': 'systolic_blood_pressure',
                    'DBP': 'diastolic_blood_pressure',
                    'BLDS': 'fasting_blood_glucose',
                    'tot_chole': 'total_cholesterol',
                    'HDL_chole': 'HDL_cholesterol',
                    'LDL_chole': 'LDL_cholesterol',
                    'SMK_stat_type_cd': 'smoker',
                    'DRK_YN': 'drinker'
                }, inplace=True)
    data['smoker'] = data['smoker'].map({1: 0, 2: 1, 3: 1})
    data['drinker'] = data['drinker'].map({'N': 0, 'Y': 1})
    data['sex'] = data['sex'].map({'Male': 1, 'Female': 0})
    # data.insert(0, 'sex_male', data.pop('sex_male'))
    # data = data.drop(columns = ['sex_male'])
    correlation = data.corr(numeric_only=True)
    dic = correlation['smoker'].to_dict()
    print(dic)
    print("belekazČ@ČČČČČČ@@@@@@")
    deleting = [key for key in dic if abs(dic[key]) < 0.2]
    data.drop(columns=deleting, inplace=True)

    columns = data.columns
    normalization = {}
    for col in columns:
        if col == 'smoker': continue
        min_val = data[col].min()
        max_val = data[col].max()
        data[col] = (data[col] - min_val) / (max_val - min_val)
        normalization[col] = (min_val, max_val)
    return data.astype(float), normalization

def split_data(data: pd.DataFrame, ans_col: str = 'smoker', random_num: int = 64, fraction = 0.001):
    data = data.sample(frac = fraction, random_state = random_num)

    smoker_data = data[data[ans_col] == 1]
    non_smoker_data = data[data[ans_col] == 0]
    answer_ratio = len(smoker_data)/len(non_smoker_data)

    training_smoker = smoker_data.sample(frac=0.8, random_state=random_num)
    training_nonsmoker = non_smoker_data.sample(frac=0.8, random_state=random_num)

    leftover_smoker = smoker_data.drop(training_smoker.index)
    leftover_nonsmoker = non_smoker_data.drop(training_nonsmoker.index)

    validation_smoker = leftover_smoker.sample(frac=0.5, random_state=random_num)
    validation_nonsmoker = leftover_nonsmoker.sample(frac=0.5, random_state=random_num)

    testing_smoker = leftover_smoker.drop(validation_smoker.index)
    testing_nonsmoker = leftover_nonsmoker.drop(validation_nonsmoker.index)

    training_set = pd.concat([training_smoker, training_nonsmoker], ignore_index=True)
    validation_set = pd.concat([validation_smoker, validation_nonsmoker], ignore_index=True)
    testing_set = pd.concat([testing_smoker, testing_nonsmoker], ignore_index=True)

    training_set = training_set.sample(frac=1, random_state=random_num)
    validation_set = validation_set.sample(frac=1, random_state=random_num)
    testing_set = testing_set.sample(frac=1, random_state=random_num)

    training_set = removing_outliers(training_set)
    return training_set, validation_set, testing_set, answer_ratio

def removing_outliers(data: pd.DataFrame):
    continuous = [column for column in data.columns if pd.api.types.is_numeric_dtype(data[column])]
    for col in continuous:
        Q1 = data[col].quantile(0.25)
        Q3 = data[col].quantile(0.75)
        IQR = Q3 - Q1
        threshold = 2
        data = data[(data[col] >= (Q1 - threshold * IQR)) & (data[col] <= (Q3 + threshold * IQR))]
    return data

def split_answer(data: np.ndarray, answer: str):
    y = data[answer].to_numpy()
    data.drop(columns = [answer], inplace=True)
    X = np.ones((len(data), len(data.columns)+1))
    X[:,1:] = data.to_numpy()
    return X, y

def get_accuracy(guess_set: list[tuple]):
    TP = len([i for i in guess_set if i[0] == 1 and i[1] == 1])
    TN = len([i for i in guess_set if i[0] == 0 and i[1] == 0])
    FP = len([i for i in guess_set if i[0] == 1 and i[1] == 0])
    FN = len([i for i in guess_set if i[0] == 0 and i[1] == 1])
    length = len(guess_set)/100
    print(f'True positives: {round(TP/length, 1)}%')
    print(f'True negatives: {round(TN/length, 1)}%')
    print(f'False positives: {round(FP/length, 1)}%')
    print(f'False negatives: {round(FN/length, 1)}%')
    print(f'Percentage of positives: {round((TP+FP) / length, 2)}%')
    print(f'\tOverall accuracy: {round((TP + TN) / len(guess_set)*100, 1)}%')

def get_scikit_model(training_set: pd.DataFrame, answer: str):
    X, y = split_answer(training_set, answer)
    svc_model = SVC(kernel='linear')
    svc_model.fit(X, y)
    return svc_model

def get_my_model(training_set: pd.DataFrame, answer: str):
    training_set = training_set.copy()
    X, y = split_answer(training_set, answer)
    y[y==0] = -1

    iterations = 50
    linear = True
    print(len(X))
    
    model = SVM(n_iters=iterations, linear=linear)
    timer = time.time()
    model.fit(X, y)
    print(f'Time taken for training: {round(time.time() - timer, 2)}s')
    filename = f'linear_model_{iterations}i_{len(X)}_{int(time.time() - timer)}s'
    print(f'saving model as file {filename}')
    with open(filename, 'wb') as f: pickle.dump(model, f)
    return model

def input_data(model: svm._classes.SVC, normalization: dict[str, tuple], data: pd.DataFrame) -> None:
    columns = list(zip(list(data.columns), list(data.mean()), [i == 2 for i in data.nunique()]))
    input_dict = {}
    for col in columns:
        key, avg, binary = col
        if key == 'smoker':
            input_dict[key] = avg
            continue
        norm = normalization[key]
        help_text = '0/1' if binary else f'Average: {round(avg * (norm[1]-norm[0]) + norm[0], 2)}'

        while(True):
            try:
                input_dict[key] = float(input(f"Please enter the value for \"{key}\" ({help_text}): "))
                if binary:
                    if input_dict[key] not in [0.0, 1.0]:
                        print('Invalid value')
                        continue
                else:
                    input_dict[key] = (input_dict[key] - norm[0]) / (norm[1] - norm[0])
                break
            except:
                print('Invalid value')
    input_dataframe = pd.DataFrame(input_dict, index=[0])[data.columns]
    y_pred = model.predict(input_dataframe.values)
    print(f'Predicted value: {"smoker" if y_pred[0] == 1. else "nonsmoker"}')

def compare_models(data: pd.DataFrame) -> None:
    _, validation_set, testing_set, _ = split_data(data, fraction=1)
    with open('linear_model_50i_3544_10s', 'rb') as f: linear_model = pickle.load(f)
    with open('poly_model_50i_3544_22s', 'rb') as f: poly_model = pickle.load(f)
    with open('rbf_model_50i_3544_1826s', 'rb') as f: rbf_model = pickle.load(f)
    testing_X, testing_Y = split_answer(testing_set, answer)
    validation_X, validation_Y = split_answer(validation_set, answer)

    linear_prediction = linear_model.predict(testing_X)[1]
    poly_prediction = poly_model.predict(testing_X)[1]
    rbf_prediction = rbf_model.predict(testing_X)[1]
    print('Linear testing set:')
    linear_prediction[linear_prediction == -1] = 0
    get_accuracy(list(zip(linear_prediction, testing_Y)))
    print('Polynomial testing set:')
    poly_prediction[poly_prediction == -1] = 0
    get_accuracy(list(zip(poly_prediction, testing_Y)))
    print('RBF testing set:')
    rbf_prediction[rbf_prediction == -1] = 0
    get_accuracy(list(zip(rbf_prediction, testing_Y)))

    print()

    linear_prediction = linear_model.predict(validation_X)[1]
    poly_prediction = poly_model.predict(validation_X)[1]
    rbf_prediction = rbf_model.predict(validation_X)[1]
    print('Linear validation set:')
    linear_prediction[linear_prediction == -1] = 0
    get_accuracy(list(zip(linear_prediction, validation_Y)))
    print('Polynomial validation set:')
    poly_prediction[poly_prediction == -1] = 0
    get_accuracy(list(zip(poly_prediction, validation_Y)))
    print('RBF validation set:')
    rbf_prediction[rbf_prediction == -1] = 0
    get_accuracy(list(zip(rbf_prediction, validation_Y)))

if __name__ == '__main__':
    np.random.seed(0)
    data, conversion = prepare_data(f'{os.getcwd()}\\smoking_dataset.csv')
    answer = 'smoker'

    compare_models(data)
    filename = 'linear_model_50i_3544_10s'
    
    if filename == '':
        training_set, validation_set, testing_set, ratio = split_data(data, fraction=0.005)
        
        model = get_my_model(training_set, answer)
        scikit_model = get_scikit_model(training_set, answer)

        validation_X, validation_Y = split_answer(validation_set, answer)
        predicted = model.predict(validation_X)[1]
        scikit_predicted = scikit_model.predict(validation_X)
        predicted[predicted == -1] = 0
        scikit_predicted[scikit_predicted == -1] = 0

        print('Mine:')
        get_accuracy(list(zip(predicted, validation_Y)))
        print('\nScikit:')
        get_accuracy(list(zip(scikit_predicted, validation_Y)))
    else:
        with open(filename, 'rb') as f: model = pickle.load(f)
        input_data(model, conversion, data)
    
    exit()
    print(f'\nWhole data:')
    X, Y = split_answer(data, answer)
    predicted = model.predict(X)[1]
    scikit_predicted = scikit_model.predict(X)
    predicted[predicted == -1] = 0
    scikit_predicted[scikit_predicted == -1] = 0
    print('Mine:')
    get_accuracy(list(zip(predicted, Y)))
    print('\nScikit:')
    get_accuracy(list(zip(scikit_predicted, Y)))

