Darbo tikslas- realizuoti prižiūrimojo mokymosi modelį aprašytai problemai spręsti ir pagal pateiktus reikalavimus parengti ataskaitą apie pasirinktą sprendimo kelią bei pasiektus rezultatus. Į inžinerinio projekto vertinimą įtraukta studentų tarpusavio vertinimo dalis.  Modeliai turi būti paruošti naudojimui su „nematytais“ duomenimis neatliekant apmokymo.

Training.ipynb failas skirtas modelio apmokymui, Predict.ipynb failas skirtas prognozuoti reiksmes pagal nematytus duomenis.
